Tale of Immortal Android bridge build kit

Repository contents required at root:
- TOI_bridge_refs.zip
- input/MOD_ncNhZv.dll
- bridge/
- patcher/
- .github/workflows/build-toi-android-bridge.yml

Run GitHub Actions -> Build TOI Android Bridge -> Run workflow.
Artifact TOI-Android-Bridge should contain:
- GGBH_MOD_Android.dll
- MOD_ncNhZv.dll (patched for current Il2CppInterop namespaces)
- SHA256SUMS.txt

Install test:
1. Remove old GGBH_MOD.dll from MelonLoader/.../Mods.
2. Put GGBH_MOD_Android.dll in MelonLoader/.../Mods.
3. Replace the test mod's ModCode/dll/MOD_ncNhZv.dll with the patched artifact DLL of the same name.
4. Keep the rest of the exported mod unchanged.
5. Launch game and collect log.
