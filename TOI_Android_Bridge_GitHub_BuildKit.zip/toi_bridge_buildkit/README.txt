TOI Android Bridge BuildKit v2

Fixes v1 startup failure on LemonLoader Android:
- no Il2CppSystem.Action<T> is constructed during Melon discovery
- removes the early Harmony patch on EventsMgr.Init
- binds GameCMDMelonLoader lazily from OnUpdate after the IL2CPP support module is active
- keeps the Android marker path fix
- keeps MOD_ncNhZv patching for Il2CppInterop

Build with the existing GitHub workflow .github/workflows/build-toi-bridge.yml in the repo.
Expected artifact: TOI-Android-Bridge

V3 / bridge 1.2.0: delay Harmony patch install until OnApplicationStart and bind GameCMDMelonLoader in EventsMgr.Init postfix using __instance. OnUpdate is fallback only.
