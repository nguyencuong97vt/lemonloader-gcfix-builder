using System;
using System.Collections.Generic;
using System.IO;
using System.Reflection;
using MelonLoader;
using MelonLoader.Utils;
using Il2Cpp;
using Il2CppEGameTypeData;

[assembly: MelonInfo(typeof(GGBH_MOD_Android.ModMain), "GGBH Android Bridge", "1.1.0", "TOI Android Port")]

namespace GGBH_MOD_Android
{
    public sealed class ModMain : MelonMod
    {
        private sealed class ModItem
        {
            public string Namespace = string.Empty;
            public readonly List<Assembly> Assemblies = new List<Assembly>();
            public object Instance;
            public bool IsLoaded;
        }

        private static readonly Dictionary<string, ModItem> AllMods =
            new Dictionary<string, ModItem>(StringComparer.Ordinal);

        // IMPORTANT: do not construct any Il2Cpp delegate while MelonLoader is still
        // discovering/instantiating mods. On Android the Il2CppInterop runtime is
        // started later by the support module. Touching Il2CppSystem.Action<T> here
        // would poison UnityVersionHandler before the runtime has started.
        private static object _gameCommandCallback;
        private static int _lastEventHashCode;
        private static int _initModMgrHashCode;

        public override void OnApplicationStart()
        {
            try
            {
                Directory.CreateDirectory(MelonEnvironment.UserDataDirectory);
                string marker = Path.Combine(
                    MelonEnvironment.UserDataDirectory,
                    "GGBH_MOD_LOAD_COMPLETE.txt"
                );
                File.WriteAllText(marker, DateTime.UtcNow.ToString("O"));
                MelonLogger.Msg("[GGBH Android] bridge initialized: " + marker);
            }
            catch (Exception ex)
            {
                MelonLogger.Msg("[GGBH Android] marker write failed: " + ex);
            }
        }

        public override void OnUpdate()
        {
            // OnUpdate is dispatched by the IL2CPP support module, so reaching this
            // point means Il2CppInterop has already been started. This deliberately
            // replaces the PC Harmony patch on EventsMgr.Init: that patch was too
            // early for LemonLoader Android.
            try
            {
                EventsMgr eventsMgr = g.events;
                if (eventsMgr == null)
                    return;

                int hash = eventsMgr.GetHashCode();
                if (_lastEventHashCode == hash)
                    return;

                _lastEventHashCode = hash;
                BindGameCommandEvent(eventsMgr);
            }
            catch (Exception ex)
            {
                // Do not spam every frame. A zero hash allows a later retry if the
                // game's event manager is recreated.
                _lastEventHashCode = 0;
                MelonLogger.Msg("[GGBH Android] OnUpdate bind retry failed: " + ex.GetType().FullName + ": " + ex.Message);
            }
        }

        private static void BindGameCommandEvent(EventsMgr eventsMgr)
        {
            try
            {
                Il2CppSystem.Action<ETypeData> callback =
                    _gameCommandCallback as Il2CppSystem.Action<ETypeData>;

                if (callback == null)
                {
                    callback = (System.Action<ETypeData>)OnGameCMDMelonLoader;
                    _gameCommandCallback = callback;
                }

                ulong eventId = eventsMgr.EventStrToUlong("GameCMDMelonLoader");
                eventsMgr.Off(eventId, callback);
                eventsMgr.On(eventId, callback, 0, false);
                MelonLogger.Msg("[GGBH Android] GameCMDMelonLoader bound, id=" + eventId);
            }
            catch (Exception ex)
            {
                _lastEventHashCode = 0;
                MelonLogger.Msg("[GGBH Android] event bind failed: " + ex);
            }
        }

        public static void OnGameCMDMelonLoader(ETypeData e)
        {
            try
            {
                CMDMelonLoader command = e.Cast<CMDMelonLoader>();
                string cmd = command.cmd ?? string.Empty;
                MelonLogger.Msg("[GGBH Android] command=" + cmd);

                if (cmd == "LoadDll")
                {
                    HandleLoadDll(command);
                    return;
                }

                if (cmd == "InitModMain")
                {
                    HandleInitModMain(command);
                    return;
                }

                if (cmd == "DestroyModMain")
                {
                    HandleDestroyModMain(command);
                }
            }
            catch (Exception ex)
            {
                MelonLogger.Msg("[GGBH Android] command handler failed: " + ex);
            }
        }

        private static void HandleLoadDll(CMDMelonLoader command)
        {
            if (command.values == null || command.values.Length < 2)
            {
                MelonLogger.Msg("[GGBH Android] LoadDll ignored: values < 2");
                return;
            }

            string filePath = command.values[0]?.ToString();
            string modNamespace = command.values[1]?.ToString();

            if (string.IsNullOrEmpty(filePath) || string.IsNullOrEmpty(modNamespace))
            {
                MelonLogger.Msg("[GGBH Android] LoadDll ignored: empty path/namespace");
                return;
            }

            try
            {
                MelonLogger.Msg("[GGBH Android] LoadDll: " + filePath + " ns=" + modNamespace);

                Assembly assembly = Assembly.LoadFrom(filePath);

                if (!AllMods.TryGetValue(modNamespace, out ModItem item))
                {
                    item = new ModItem { Namespace = modNamespace };
                    AllMods.Add(modNamespace, item);
                }

                bool exists = false;
                foreach (Assembly loaded in item.Assemblies)
                {
                    if (string.Equals(loaded.FullName, assembly.FullName, StringComparison.Ordinal))
                    {
                        exists = true;
                        break;
                    }
                }

                if (!exists)
                    item.Assemblies.Add(assembly);

                MelonLogger.Msg("[GGBH Android] DLL loaded: " + assembly.FullName);
            }
            catch (Exception ex)
            {
                MelonLogger.Msg("[GGBH Android] LoadDll FAILED: " + ex);
            }
        }

        private static void HandleInitModMain(CMDMelonLoader command)
        {
            try
            {
                ModMgr modMgr = g.mod;
                if (modMgr != null)
                {
                    int hash = modMgr.GetHashCode();
                    if (_initModMgrHashCode == hash)
                    {
                        MelonLogger.Msg("[GGBH Android] InitModMain duplicate ignored");
                        return;
                    }
                    _initModMgrHashCode = hash;
                }
            }
            catch
            {
            }

            DestroyLoadedInstances(null);

            HashSet<string> requested = ReadNamespaceSet(command);

            foreach (KeyValuePair<string, ModItem> pair in AllMods)
            {
                ModItem item = pair.Value;
                if (requested.Count != 0 && !requested.Contains(item.Namespace))
                    continue;

                if (item.Instance == null)
                {
                    string typeName = item.Namespace + ".ModMain";

                    foreach (Assembly assembly in item.Assemblies)
                    {
                        Type type = assembly.GetType(typeName, false);
                        if (type == null)
                            continue;

                        item.Instance = Activator.CreateInstance(type);
                        break;
                    }
                }

                if (item.Instance == null)
                {
                    MelonLogger.Msg("[GGBH Android] Can't find " + item.Namespace + ".ModMain");
                    continue;
                }

                try
                {
                    MethodInfo init = item.Instance.GetType().GetMethod(
                        "Init",
                        BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance
                    );

                    if (init == null)
                        throw new MissingMethodException(item.Instance.GetType().FullName, "Init");

                    init.Invoke(item.Instance, Array.Empty<object>());
                    item.IsLoaded = true;
                    MelonLogger.Msg("[GGBH Android] InitModMain: " + item.Namespace);
                }
                catch (Exception ex)
                {
                    item.IsLoaded = false;
                    MelonLogger.Msg("[GGBH Android] InitModMain FAILED " + item.Namespace + ": " + ex);
                }
            }
        }

        private static void HandleDestroyModMain(CMDMelonLoader command)
        {
            HashSet<string> requested = ReadNamespaceSet(command);
            DestroyLoadedInstances(requested.Count == 0 ? null : requested);
        }

        private static void DestroyLoadedInstances(HashSet<string> filter)
        {
            foreach (KeyValuePair<string, ModItem> pair in AllMods)
            {
                ModItem item = pair.Value;

                if (filter != null && !filter.Contains(item.Namespace))
                    continue;

                if (item.Instance == null)
                    continue;

                try
                {
                    MethodInfo destroy = item.Instance.GetType().GetMethod(
                        "Destroy",
                        BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance
                    );

                    destroy?.Invoke(item.Instance, Array.Empty<object>());
                    MelonLogger.Msg("[GGBH Android] DestroyModMain: " + item.Namespace);
                }
                catch (Exception ex)
                {
                    MelonLogger.Msg("[GGBH Android] DestroyModMain FAILED " + item.Namespace + ": " + ex);
                }
                finally
                {
                    item.Instance = null;
                    item.IsLoaded = false;
                }
            }
        }

        private static HashSet<string> ReadNamespaceSet(CMDMelonLoader command)
        {
            HashSet<string> result = new HashSet<string>(StringComparer.Ordinal);

            if (command.values == null)
                return result;

            for (int i = 0; i < command.values.Length; i++)
            {
                object value = command.values[i];
                if (value == null)
                    continue;

                string text = value.ToString();
                if (!string.IsNullOrEmpty(text))
                    result.Add(text);
            }

            return result;
        }
    }

}
