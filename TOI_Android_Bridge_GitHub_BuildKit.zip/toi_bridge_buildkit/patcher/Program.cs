using Mono.Cecil;

if (args.Length != 4)
{
    Console.Error.WriteLine("Usage: Patcher <old-mod.dll> <Assembly-CSharp.dll> <Il2CppInterop.Runtime.dll> <output.dll>");
    return 2;
}

string input = args[0];
string gameAssemblyPath = args[1];
string interopRuntimePath = args[2];
string output = args[3];

using var gameAssembly = AssemblyDefinition.ReadAssembly(gameAssemblyPath);
using var interopRuntime = AssemblyDefinition.ReadAssembly(interopRuntimePath);
using var mod = AssemblyDefinition.ReadAssembly(input, new ReaderParameters { ReadWrite = false });

var gameTypes = new HashSet<string>(
    gameAssembly.MainModule.Types.Select(t => t.FullName),
    StringComparer.Ordinal
);

AssemblyNameReference? interopRef = mod.MainModule.AssemblyReferences
    .FirstOrDefault(x => x.Name == interopRuntime.Name.Name);

if (interopRef == null)
{
    interopRef = new AssemblyNameReference(
        interopRuntime.Name.Name,
        interopRuntime.Name.Version
    )
    {
        Culture = interopRuntime.Name.Culture,
        PublicKeyToken = interopRuntime.Name.PublicKeyToken
    };
    mod.MainModule.AssemblyReferences.Add(interopRef);
}

int gameNamespacePatches = 0;
int arrayPatches = 0;

foreach (TypeReference tr in mod.MainModule.GetTypeReferences())
{
    string scopeName = tr.Scope?.Name ?? string.Empty;

    if (scopeName == "Assembly-CSharp" && string.IsNullOrEmpty(tr.Namespace))
    {
        string candidate = "Il2Cpp." + tr.Name;
        if (gameTypes.Contains(candidate))
        {
            Console.WriteLine($"Game type: {tr.FullName} -> {candidate}");
            tr.Namespace = "Il2Cpp";
            gameNamespacePatches++;
        }
    }

    if (scopeName == "UnhollowerBaseLib" &&
        tr.Namespace == "UnhollowerBaseLib" &&
        tr.Name == "Il2CppArrayBase`1")
    {
        Console.WriteLine("Array type: UnhollowerBaseLib.Il2CppArrayBase`1 -> Il2CppInterop.Runtime.InteropTypes.Arrays.Il2CppArrayBase`1");
        tr.Namespace = "Il2CppInterop.Runtime.InteropTypes.Arrays";
        tr.Scope = interopRef;
        arrayPatches++;
    }
}

bool stillUsesUnhollower = mod.MainModule.GetTypeReferences().Any(
    t => string.Equals(t.Scope?.Name, "UnhollowerBaseLib", StringComparison.Ordinal)
);

if (!stillUsesUnhollower)
{
    var oldRef = mod.MainModule.AssemblyReferences
        .FirstOrDefault(x => x.Name == "UnhollowerBaseLib");
    if (oldRef != null)
        mod.MainModule.AssemblyReferences.Remove(oldRef);
}

Directory.CreateDirectory(Path.GetDirectoryName(Path.GetFullPath(output))!);
mod.Write(output);

using var verify = AssemblyDefinition.ReadAssembly(output);

bool badUnhollower = verify.MainModule.AssemblyReferences.Any(x => x.Name == "UnhollowerBaseLib") ||
    verify.MainModule.GetTypeReferences().Any(t => t.Namespace == "UnhollowerBaseLib");

if (badUnhollower)
    throw new Exception("Patch verification failed: UnhollowerBaseLib reference remains");

if (gameNamespacePatches == 0)
    throw new Exception("Patch verification failed: no Assembly-CSharp namespace references were changed");

if (arrayPatches == 0)
    throw new Exception("Patch verification failed: Il2CppArrayBase was not changed");

Console.WriteLine($"SUCCESS gameTypePatches={gameNamespacePatches}, arrayPatches={arrayPatches}");
return 0;
